/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Nick
 */
public class CD extends Product{
        //Constructor
        public CD(){}
        public CD(String name, int price){
            super(name,price);
        }

}


