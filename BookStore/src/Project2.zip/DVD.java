/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Nick
 */
public class DVD extends Product{
    
        //Constructor
        public DVD(){}
        public DVD(String name, int price){
            super(name,price);

        }
}
